---
name: decision-tool-builder
description: "Builds a decision tool from a problem. Use this skill when the user must choose between options, cannot decide, or asks for help to decide. The skill gathers context and chooses a method. The skill helps the user list options. The skill builds one interactive HTML file with a Save button. Trigger phrases: help me decide, what should I do, pros and cons, should I take this job. More trigger phrases: how do I choose, decision matrix, prioritize my tasks. Also use the skill when the user wants to think through a risky plan, even if the user does not say decision tool. Do not use the skill for simple facts. Do not use the skill when the user is in crisis."
---

# Decision tool builder

This skill changes a problem into a decision tool. The result is one HTML file. The user opens the file, writes in it, and saves it.

## Steps

1. **Intake.** Learn the problem.
2. **Diagnose.** Choose the tool.
3. **Elicit.** Get the options, criteria, and numbers from the user.
4. **Build.** Write a config file. Run the build script.
5. **Deliver.** Give the file and a short explanation to the user.

Do not skip steps 1 and 2. A good tool for the wrong problem does not help the user.

## Language

Write all text for the user in Simplified Technical English (STE). This includes chat replies, config text, and notes. Many users are not native speakers of English. Some users are not technical.

1. Read `references/ste-writing.md` before you write.
2. Use the `asd-ste100` skill for the text if it is available.
3. Run `scripts/ste_check.py` on the config before you build.

The rules in short:

- Write one instruction in each sentence.
- Use 20 words or fewer in an instruction. Use 25 words or fewer in a description.
- Use the active voice and simple tenses.
- Do not use semicolons.
- Do not use phrasal verbs. Write "find" and not "look for".
- Use one word for one meaning. Use the terms in the vocabulary table in `references/ste-writing.md`.
- Use US spelling.

If the user writes in another language, write in that language. Keep the sentences short and plain. Put the page text in that language with the `ui` setting. See `references/html-config.md`.

## When not to use this skill

- The user wants one fact or one answer and says "just tell me". Answer the question. You may say that you can build a tool.
- The user shows signs of crisis, such as self-harm, or says that they have no hope. Do not build a tool. Reply with care. Follow your safety rules.
- The topic is health, law, or money. You may build the tool. Say one time that the tool helps the user think and is not professional advice. Tell the user to ask a qualified person for the final check.

## Step 1: Intake

Read `references/elicitation.md`. It has the checklist, the questions, and the rules for how to ask.

You need these items before you choose a tool (the readiness gate):

| Item | Reason |
|---|---|
| One sentence that states the **decision question** | The tool uses it. |
| The **kind of decision** | The kind decides the tool family. |
| **Reversibility.** The user can or cannot undo the decision. | It decides how much effort the decision needs. |
| The **stakes** and the **deadline** | They decide the depth and the speed. |
| What the user **knows** and does **not know** | It decides if analysis, tests, or action comes first. |

Kinds of decision:

- choose between options, go or no-go, prioritize, risky bet
- change, goal, understand myself, feedback
- team or people, find ideas, learn from a mistake

Rules for questions:

1. Take every fact from the message of the user first. Do not ask for a fact that you have.
2. Ask only for items that you need and that change the tool. Ask 3 questions or fewer in one message.
3. Use the `ask_user_input_v0` function for questions with short answers, if it is available. Otherwise ask in plain text.
4. Give your best guess and ask "Is this what you mean?". It is easier for the user to react than to create.
5. Do not interrogate the user. If the user says "just go", continue. Write each guess in the `assumptions` list.
6. Never invent facts, prices, chances, or dates. If a number is missing, leave it empty or label it as an assumption.

## Step 2: Diagnose and choose the tool

Read `references/tool-selection.md`. It has the diagnosis questions, the routing table, and the pairings.

1. Classify the decision on six axes: kind, reversibility, uncertainty, state of the options, people, and numbers.
2. Choose **one main tool**. Add **one second tool** only if the decision is hard to undo. The second tool is a stress test, for example the pre-mortem or the 10/10/10 test.
3. Never build more than 3 tools. Too many tools cause choice overload.
4. For a small decision that the user can undo, use a light tool. Tell the user to decide fast. Do not use more tools than the decision needs.
5. If two tools fit, choose the simpler tool. Write the other tool in `alsoConsider`.
6. Write one or two short sentences in `toolSelection.why`. Use the same sentences in your reply.

Run `python scripts/build_tool.py --list` to see the preset ids. Read the entry for each chosen tool in `references/tool-catalog.md`. Do not read the entries for other tools.

## Step 3: Elicit the tool inputs

Get the inputs that the catalog entry lists. Use these rules:

- **Widen the options first.** Many users bring two options. Ask if the user can do both. Ask if the user can run a small test. Ask one time: "If none of these options were possible, what would you do?" Add "do nothing" as an option.
- **Keep 5 options or fewer.** Keep 7 criteria or fewer. More than this makes the decision worse. Help the user remove the weakest.
- **Take the criteria from the values of the user.** Give a draft list. Ask the user to remove, add, and weigh the criteria. Do not set weights unless the user asks. If you set weights, write this in `assumptions`.
- **Leave the judgments to the user.** Do not fill scores, chances, or ratings that the user did not give. A tool with your opinions in it is not the decision of the user.
- For tools with boxes, place an item only if the place is clear. Leave other items as "not placed yet".
- Mark each option that you add with "(suggested)".

## Step 4: Build the HTML file

The script builds the file. Do not write the HTML by hand.

1. Read `references/html-config.md`. It shows the config format.
2. Look at `examples/` for two complete configs.
3. Write the config as a JSON file, for example `/home/claude/config.json`. Use the words of the user for the problem.
4. Run `python scripts/ste_check.py /home/claude/config.json`. Fix each finding. Run it again.
5. Run the build script:

   ```bash
   python <skill-folder>/scripts/build_tool.py /home/claude/config.json /mnt/user-data/outputs/<short-name>-decision-tool.html
   ```

   `<skill-folder>` is the folder that holds this SKILL.md.
6. Fix each `ERROR`. Read each `WARNING`. Fix the config if the warning applies.

The file has the **whiteboard pattern**. `references/output-pattern.md` describes it. The page has:

- a dot-grid board and a fixed top bar with jump chips and the buttons Save, Load, and Print
- a title, and boxes for the deadline, stakes, reversibility, and owner
- the decision question on a sticky note
- boxes for the situation, the assumptions that the user must check, and the reason for the tool
- one card for each tool
- in each card: a numbered "How to use it" list, a "How to read the result" note, and a "Read this as text" section
- the "Your decision" form and a box for notes

The **Save my decision** button downloads a JSON file. It also saves in the browser. It also opens a drawer with a text summary that the user can copy.

If the user writes in another language, set `meta.language`. Translate the page text with `ui`. See section 9 of `references/html-config.md`.

Check the file before you deliver it. If a headless browser is available, take one screenshot. Make sure that the problem, the tool, and the buttons show. If no browser is available, make sure that the build has no errors.

## Step 5: Deliver

- Call the `present_files` function with the HTML file. Do not publish the file unless the user asks for a hosted page. A published page cannot download files. Tell the user this if the user asks for a hosted page. The copy button in the drawer still works.
- Write a short reply:
  1. One or two sentences. Name the tool and give the reason.
  2. Two or three sentences. Tell the user how to use the tool: write in it, read the result, write the decision, press Save.
  3. One sentence about an important assumption, if you made one.
  4. One question at most. Ask it only if the answer improves the tool.
- Do not tell the user what to decide. If the user asks for your opinion after the use of the tool, give it. Say that it is your opinion and not a rule.
- Do not repeat the content of the tool in the chat.

## Resume and change

If the user returns with a saved JSON file or a summary, read it. Ask what changed. Build the file again with new options, or add a second tool. Or move to the next step, for example from the weighted matrix to a pre-mortem of the top option.

## Good habits

These ideas come from the sources of the presets. Use them when you coach the user.

- Most decisions can be undone. Decide fast when the user can undo the decision. Decide slowly when the user cannot. Change a one-way door into a two-way door with a pilot or a trial.
- No decision is also a decision. Give a deadline.
- Decide with enough information. Do not decide too early or too late.
- The feeling of the user is data. Ask for it before the scoring. Compare it with the result.
- Assume that the user can be wrong. Plan the warning sign before the start.
- Limits protect the user. Use a research limit, an option limit, and a stop rule.

## Files in this skill

- `references/ste-writing.md`: the STE rules and the vocabulary.
- `references/elicitation.md`: the intake checklist and the questions.
- `references/tool-selection.md`: the diagnosis and the routing table.
- `references/tool-catalog.md`: one entry for each preset.
- `references/html-config.md`: the config format.
- `references/output-pattern.md`: the look of the page.
- `assets/decision-tool-template.html`: the HTML template. Do not change it for one job.
- `assets/presets.json`: the preset library.
- `scripts/build_tool.py`: merges presets, checks the config, and builds the file.
- `scripts/ste_check.py`: checks the text of a config against the STE rules.
- `examples/`: two complete configs and the files that they build.
- `evals/evals.json`: test prompts.
